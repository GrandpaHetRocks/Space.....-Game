import pygame
import random
import os
import sys
from pygame.locals import *
def spawn(ex,ey,eim,bl):
        ex.append(random.randint(0,650))
        ey.append(random.randint(0,30))
        we=pygame.image.load("enemy.png").convert_alpha()
        eim.append(we)
        chec=0
        return(ex,ey,eim,bl)
check=0
def ooo():
    pygame.init()
    global score
    score=0
    display_width = 750
    display_height = 700
    gameDisplay = pygame.display.set_mode((display_width,display_height))
    pygame.display.set_caption('SUGGEST A COOL NAME PLS')
    run=True
    clock=pygame.time.Clock()
    bgy=0
    bgy1=-700
    a=pygame.image.load("back.jpg").convert()
    b=pygame.transform.scale(a,(750,700))
    c=pygame.image.load("back.jpg").convert()
    d=pygame.transform.scale(a,(750,700))
    e=pygame.image.load("ship.png").convert_alpha()
    f=pygame.transform.scale(e,(70,70))
    g=pygame.image.load("bul.png").convert_alpha()
    h=pygame.transform.scale(g,(20,20))
    sp=80
    x=375
    y=350
    chec=1
    sh=0
    bx=100
    by=100
    
    ex=[]
    ey=[]
    eim=[]
    bl=[]
    
    while(run):
        font = pygame.font.Font('freesansbold.ttf', 20)
        if(chec==1):
            noe=15
            for i in range(noe):
                ex,ey,eim,bl=spawn(ex,ey,eim,bl)
            chec=0
        no=noe
        clock.tick(sp)
        if(bgy1<=0):
            gameDisplay.blit(b, (0,bgy))
            gameDisplay.blit(d, (0,bgy1))
            bgy+=1.4
            bgy1+=1.4
        else:
            bgy=0
            bgy1=-700
            gameDisplay.blit(b, (0,bgy))
            gameDisplay.blit(d, (0,bgy1))
        for event in pygame.event.get():
                if(event.type==pygame.QUIT):
                    run=False
        keys=pygame.key.get_pressed()
        if(keys[pygame.K_UP]):
            if(y>=0):
                y-=4
            gameDisplay.blit(f, (x,y))
        if(keys[pygame.K_DOWN]):
            if(y<=630):
                y+=4
            gameDisplay.blit(f, (x,y))
        if(keys[pygame.K_RIGHT]):
            if(x<=680):
                x+=4
            gameDisplay.blit(f, (x,y))
        if(keys[pygame.K_LEFT]):
            if(x>=0):
                x-=4
            gameDisplay.blit(f, (x,y))
        if(sh!=1 and keys[pygame.K_c]):
            sh=1
            bx=x
            by=y
        gameDisplay.blit(f, (x,y))
        
        for i in range (0,noe):
            we=pygame.transform.scale(eim[i],(70,70))
            gameDisplay.blit(we, (ex[i],ey[i]))
            ey[i]+=1.8
            if(ey[i]>630):
                ex,ey,eim,bl=spawn(ex,ey,eim,bl)
                chec=0
                run=False
                check=1
                break
            if(bx>=ex[i]-35 and bx<=ex[i]+35 and by<ey[i]+35 and by>ey[i]-35):
                eim.remove(eim[i])
                ex.remove(ex[i])
                ey.remove(ey[i])
                score+=1
                ex,ey,eim,bl=spawn(ex,ey,eim,bl)
        if(sh==1):
            by-=20
            gameDisplay.blit(h, (bx,by))
            if(by<0):
                sh=0
        if(x>=ex[i]-35 and x<=ex[i]+35 and y<ey[i]+35 and y>ey[i]-35):
            run=False
            check=1
        sco = font.render("Score:"+str(score), True, (0,0,0), (255,255,255))
        textRectsco = sco.get_rect()
        textRectsco.center = (600,100)
        gameDisplay.blit(sco, textRectsco)
        pygame.display.update()
    if(check==1):
        run=True
        while(run):
            gameDisplay.blit(sco, textRectsco)
            for event in pygame.event.get():
                if(event.type==pygame.QUIT):
                    run=False
            keys=pygame.key.get_pressed()
            if(keys[pygame.K_r]):
                ooo()
ooo()
print(score)